export type AgencyStatus = "active" | "suspended" | "expired";

export interface Agency {
  id: string;
  name: string;
  slug: string;
  licenseNo: string;
  city: string;
  address?: string;
  phone?: string;
  email?: string;
  website?: string;
  sectors: string[]; // parsed from JSON string
  rating: number;
  reviewCount: number;
  isVerified: boolean;
  status: AgencyStatus;
  description?: string;
  foundedYear?: number;
  vacancyCount: number;
  logoUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatarUrl?: string;
  country?: string;
  isFeatured: boolean;
  createdAt: string;
}

export type Sector =
  | "Hospitality"
  | "Healthcare"
  | "IT & Tech"
  | "Construction"
  | "Retail"
  | "Manufacturing"
  | "Education"
  | "Domestic Work"
  | "Logistics"
  | "Engineering"
  | "Finance"
  | "Agriculture";

export const ALL_SECTORS: Sector[] = [
  "Hospitality",
  "Healthcare",
  "IT & Tech",
  "Construction",
  "Retail",
  "Manufacturing",
  "Education",
  "Domestic Work",
  "Logistics",
  "Engineering",
  "Finance",
  "Agriculture",
];

export interface SearchFilters {
  query?: string;
  sector?: Sector | "All";
  city?: string;
  status?: AgencyStatus;
}

export interface AgencyApiResponse {
  agencies: Agency[];
  total: number;
  page: number;
  limit: number;
  sectors: Sector[];
  cities: string[];
}