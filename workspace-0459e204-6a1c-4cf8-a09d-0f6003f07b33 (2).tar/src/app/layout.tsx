import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "WorkinGulf | Sri Lankan Employment Agency Directory",
  description:
    "Find SLBFE-verified Sri Lankan employment agencies for safe overseas jobs in UAE, Saudi Arabia, Qatar, Kuwait, and more. Search by sector, city, or license number.",
  keywords: [
    "Sri Lankan employment agencies",
    "SLBFE verified",
    "Gulf jobs Sri Lanka",
    "overseas employment Sri Lanka",
    "foreign employment bureau",
    "work in Dubai Sri Lanka",
    "recruitment agencies Sri Lanka",
    "migrant workers Sri Lanka",
  ],
  authors: [{ name: "WorkinGulf Team" }],
  openGraph: {
    title: "WorkinGulf | Sri Lankan Employment Agency Directory",
    description:
      "Your trusted directory of SLBFE-verified Sri Lankan employment agencies for safe overseas employment.",
    type: "website",
    locale: "en_LK",
    siteName: "WorkinGulf",
  },
  twitter: {
    card: "summary_large_image",
    title: "WorkinGulf | Sri Lankan Employment Agency Directory",
    description:
      "Find verified Sri Lankan employment agencies for safe overseas jobs.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <div className="flex min-h-screen flex-col">{children}</div>
        </ThemeProvider>
        <Toaster />
      </body>
    </html>
  );
}