"use client";

import { useState, useEffect, useCallback } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/sections/Hero";
import { Stats } from "@/components/sections/Stats";
import { SectorFilters } from "@/components/sections/SectorFilters";
import { AgencyGrid } from "@/components/sections/AgencyGrid";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Testimonials } from "@/components/sections/Testimonials";
import { TrustSection } from "@/components/sections/TrustSection";
import type { Agency, Sector, AgencyApiResponse } from "@/lib/types";

export default function Home() {
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [availableSectors, setAvailableSectors] = useState<Sector[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeSector, setActiveSector] = useState<Sector | "All">("All");
  const [searchQuery, setSearchQuery] = useState("");

  const fetchAgencies = useCallback(async (query?: string) => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (query) params.set("q", query);
      const res = await fetch(`/api/agencies?${params.toString()}`);
      const data: AgencyApiResponse = await res.json();
      setAgencies(data.agencies);
      setAvailableSectors(data.sectors);
    } catch (error) {
      console.error("Failed to fetch agencies:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAgencies();
  }, [fetchAgencies]);

  const handleSearch = useCallback(
    (query: string) => {
      setSearchQuery(query);
      fetchAgencies(query);
    },
    [fetchAgencies]
  );

  return (
    <>
      <Header />
      <main className="flex-1">
        <Hero onSearch={handleSearch} resultCount={agencies.length} />
        <Stats />
        <SectorFilters
          activeSector={activeSector}
          onSectorChange={setActiveSector}
          availableSectors={availableSectors}
        />
        <AgencyGrid
          agencies={agencies}
          isLoading={isLoading}
          activeSector={activeSector}
          searchQuery={searchQuery}
        />
        <HowItWorks />
        <Testimonials />
        <TrustSection />
      </main>
      <Footer />
    </>
  );
}