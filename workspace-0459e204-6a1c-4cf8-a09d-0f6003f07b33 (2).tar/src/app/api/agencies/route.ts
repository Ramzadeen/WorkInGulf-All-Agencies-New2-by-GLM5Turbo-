import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { Agency, Sector, AgencyApiResponse } from "@/lib/types";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const query = searchParams.get("q")?.toLowerCase() || "";
    const sector = searchParams.get("sector") || "All";
    const page = parseInt(searchParams.get("page") || "1", 10);
    const limit = parseInt(searchParams.get("limit") || "50", 10);

    const where: Record<string, unknown> = { status: "active" };

    if (query) {
      where.OR = [
        { name: { contains: query } },
        { city: { contains: query } },
        { licenseNo: { contains: query } },
      ];
    }

    if (sector && sector !== "All") {
      where.sectors = { contains: sector };
    }

    const [rawAgencies, total] = await Promise.all([
      db.agency.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { rating: "desc" },
      }),
      db.agency.count({ where }),
    ]);

    const agencies: Agency[] = rawAgencies.map((a) => ({
      ...a,
      sectors: JSON.parse(a.sectors),
      createdAt: a.createdAt.toISOString(),
      updatedAt: a.updatedAt.toISOString(),
    }));

    // Get unique cities and sectors
    const allActive = await db.agency.findMany({ where: { status: "active" } });
    const cities = [...new Set(allActive.map((a) => a.city))].sort();
    const allSectors: Set<string> = new Set();
    allActive.forEach((a) => {
      JSON.parse(a.sectors).forEach((s: string) => allSectors.add(s));
    });

    const response: AgencyApiResponse = {
      agencies,
      total,
      page,
      limit,
      sectors: [...allSectors].sort() as Sector[],
      cities,
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error("Error fetching agencies:", error);
    return NextResponse.json(
      { error: "Failed to fetch agencies" },
      { status: 500 }
    );
  }
}