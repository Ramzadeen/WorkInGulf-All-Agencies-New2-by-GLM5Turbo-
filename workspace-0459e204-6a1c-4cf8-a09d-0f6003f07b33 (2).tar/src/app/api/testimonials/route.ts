import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { Testimonial } from "@/lib/types";

export async function GET() {
  try {
    const raw = await db.testimonial.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
    });

    const testimonials: Testimonial[] = raw.map((t) => ({
      ...t,
      createdAt: t.createdAt.toISOString(),
    }));

    return NextResponse.json(testimonials);
  } catch (error) {
    console.error("Error fetching testimonials:", error);
    return NextResponse.json(
      { error: "Failed to fetch testimonials" },
      { status: 500 }
    );
  }
}