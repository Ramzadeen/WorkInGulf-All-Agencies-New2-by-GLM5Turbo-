import Link from "next/link";
import {
  ShieldCheck,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  ArrowUpRight,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

const footerLinks = {
  "For Job Seekers": [
    { label: "Browse Agencies", href: "#" },
    { label: "Search Vacancies", href: "#" },
    { label: "Safety Guide", href: "#" },
    { label: "SLBFE Registration", href: "#" },
    { label: "Document Checklist", href: "#" },
  ],
  "For Agencies": [
    { label: "List Your Agency", href: "#" },
    { label: "Post Vacancies", href: "#" },
    { label: "Advertising", href: "#" },
    { label: "Partner Program", href: "#" },
  ],
  Resources: [
    { label: "About WorkinGulf", href: "#" },
    { label: "Blog & News", href: "#" },
    { label: "Gulf Country Guides", href: "#" },
    { label: "FAQ", href: "#" },
    { label: "Privacy Policy", href: "#" },
    { label: "Terms of Service", href: "#" },
  ],
};

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
  { icon: Instagram, href: "#", label: "Instagram" },
];

export function Footer() {
  return (
    <footer id="contact" className="bg-navy text-navy-foreground/70">
      {/* Newsletter Section */}
      <div className="border-b border-white/10">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
            <div className="text-center md:text-left">
              <h3 className="text-lg font-semibold text-navy-foreground">
                Stay Updated with New Vacancies
              </h3>
              <p className="mt-1 text-sm">
                Get the latest verified job openings delivered to your inbox weekly.
              </p>
            </div>
            <div className="flex w-full max-w-md gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="h-11 flex-1 border-white/20 bg-white/5 text-navy-foreground placeholder:text-navy-foreground/40 focus-visible:ring-emerald-accent"
                aria-label="Email for newsletter"
              />
              <Button className="h-11 bg-emerald-accent text-white hover:bg-emerald-hover shrink-0">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2" aria-label="WorkinGulf Home">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-accent">
                <ShieldCheck className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-navy-foreground">
                Workin<span className="text-emerald-accent">Gulf</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed">
              Sri Lanka&apos;s most trusted directory of SLBFE-verified employment
              agencies. Connecting qualified Sri Lankan workers with safe, legitimate
              overseas employment opportunities since 2024.
            </p>
            <div className="mt-6 flex gap-3">
              {socialLinks.map(({ icon: Icon, href, label }) => (
                <Link
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 text-navy-foreground/50 transition-colors hover:bg-emerald-accent/20 hover:text-emerald-accent"
                >
                  <Icon className="h-4 w-4" />
                </Link>
              ))}
            </div>
            <div className="mt-6 space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-emerald-accent" />
                <span>+94 11 287 7711 (SLBFE)</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-emerald-accent" />
                <span>info@workingulf.lk</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-emerald-accent" />
                <span>Colombo, Sri Lanka</span>
              </div>
            </div>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-navy-foreground">
                {title}
              </h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="group inline-flex items-center gap-1 text-sm transition-colors hover:text-emerald-accent"
                    >
                      {link.label}
                      <ArrowUpRight className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Bar */}
      <Separator className="bg-white/10" />
      <div className="mx-auto max-w-7xl px-4 py-5 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-3 text-xs sm:flex-row">
          <p>
            &copy; {new Date().getFullYear()} WorkinGulf. All Rights Reserved.
            Verified Directory for Sri Lankan Job Seekers.
          </p>
          <p className="flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-accent" />
            All agencies verified against official SLBFE registry
          </p>
        </div>
      </div>
    </footer>
  );
}