"use client";

import { useState } from "react";
import Link from "next/link";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import {
  Menu,
  Moon,
  Sun,
  ShieldCheck,
  Phone,
} from "lucide-react";

const navLinks = [
  { label: "Home", href: "#", active: true },
  { label: "Agencies", href: "#agencies" },
  { label: "Vacancies", href: "#" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Contact", href: "#contact" },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useState(() => {
    setMounted(true);
  });

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-navy backdrop-blur-md supports-[backdrop-filter]:bg-navy/90">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2" aria-label="WorkinGulf Home">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-accent">
            <ShieldCheck className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold text-navy-foreground">
            Workin<span className="text-emerald-accent">Gulf</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex md:items-center md:gap-1" aria-label="Main navigation">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className={`rounded-md px-3 py-2 text-sm font-medium transition-colors hover:text-emerald-accent ${
                link.active
                  ? "text-emerald-accent"
                  : "text-navy-foreground/70"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden md:flex md:items-center md:gap-3">
          {/* Dark mode toggle */}
          {mounted && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="text-navy-foreground/70 hover:text-emerald-accent hover:bg-white/10"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-navy-foreground/70 hover:text-emerald-accent hover:bg-white/10"
          >
            <Phone className="h-4 w-4" />
            <span className="text-xs">SLBFE Hotline</span>
          </Button>
          <Button
            size="sm"
            className="bg-emerald-accent text-white hover:bg-emerald-hover"
          >
            List Your Agency
          </Button>
        </div>

        {/* Mobile Menu */}
        <div className="flex items-center gap-2 md:hidden">
          {mounted && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="text-navy-foreground/70 hover:text-emerald-accent hover:bg-white/10"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          )}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-navy-foreground/70 hover:bg-white/10"
                aria-label="Open menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 bg-navy border-white/10">
              <SheetTitle className="text-navy-foreground sr-only">Navigation Menu</SheetTitle>
              <div className="flex flex-col gap-1 pt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.label}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className={`rounded-md px-4 py-3 text-sm font-medium transition-colors hover:bg-white/10 ${
                      link.active
                        ? "text-emerald-accent bg-white/5"
                        : "text-navy-foreground/70"
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                <div className="mt-4 border-t border-white/10 pt-4">
                  <Button className="w-full bg-emerald-accent text-white hover:bg-emerald-hover">
                    List Your Agency
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}