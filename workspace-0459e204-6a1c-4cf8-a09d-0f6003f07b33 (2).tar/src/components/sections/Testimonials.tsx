"use client";

import { useState, useEffect } from "react";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Testimonial } from "@/lib/types";

export function Testimonials() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    fetch("/api/testimonials")
      .then((res) => res.json())
      .then(setTestimonials)
      .catch(console.error);
  }, []);

  if (testimonials.length === 0) return null;

  const itemsPerView = testimonials.length >= 3 ? 3 : testimonials.length;
  const maxIndex = Math.max(0, testimonials.length - itemsPerView);

  const prev = () => setCurrentIndex((i) => Math.max(0, i - 1));
  const next = () => setCurrentIndex((i) => Math.min(maxIndex, i + 1));

  return (
    <section className="py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-wider text-emerald-accent">
            Success Stories
          </span>
          <h2 className="mt-2 text-2xl font-bold text-foreground sm:text-3xl">
            What Workers Say About Us
          </h2>
          <p className="mt-3 text-sm text-muted-foreground sm:text-base">
            Real experiences from Sri Lankan workers who found overseas
            employment through our verified agencies.
          </p>
        </div>

        <div className="relative mt-10">
          {/* Navigation buttons */}
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={prev}
              disabled={currentIndex === 0}
              className="h-9 w-9 rounded-full"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={next}
              disabled={currentIndex >= maxIndex}
              className="h-9 w-9 rounded-full"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Cards */}
          <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {testimonials
              .slice(currentIndex, currentIndex + 3)
              .map((t) => (
                <Card
                  key={t.id}
                  className="border-border/60 bg-card transition-all duration-300 hover:shadow-md"
                >
                  <CardContent className="pt-6">
                    <Quote className="mb-3 h-8 w-8 text-emerald-accent/20" />
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      &ldquo;{t.content}&rdquo;
                    </p>
                    <div className="mt-5 flex items-center gap-3">
                      {/* Avatar */}
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-soft text-sm font-bold text-emerald-accent">
                        {t.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-foreground">
                          {t.name}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">
                          {t.role}
                        </p>
                      </div>
                      <div className="ml-auto flex">
                        {Array.from({ length: t.rating }).map((_, i) => (
                          <Star
                            key={i}
                            className="h-3.5 w-3.5 fill-amber-400 text-amber-400"
                          />
                        ))}
                      </div>
                    </div>
                    {t.country && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        Placed in {t.country}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      </div>
    </section>
  );
}