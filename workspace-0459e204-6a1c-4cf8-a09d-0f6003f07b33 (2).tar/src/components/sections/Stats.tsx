import {
  Building2,
  ShieldCheck,
  Users,
  Globe,
} from "lucide-react";

const stats = [
  {
    icon: Building2,
    value: "250+",
    label: "Verified Agencies",
    description: "SLBFE-licensed recruitment firms",
  },
  {
    icon: ShieldCheck,
    value: "100%",
    label: "License Verified",
    description: "Checked against official registry",
  },
  {
    icon: Users,
    value: "15,000+",
    label: "Successful Placements",
    description: "Workers placed in Gulf countries",
  },
  {
    icon: Globe,
    value: "8",
    label: "Destination Countries",
    description: "UAE, Saudi, Qatar, Kuwait & more",
  },
];

export function Stats() {
  return (
    <section className="relative z-10 -mt-10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-3 rounded-2xl border border-border bg-card p-4 shadow-lg sm:gap-4 sm:p-6 lg:grid-cols-4 lg:gap-6 lg:p-8">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="group flex flex-col items-center text-center"
            >
              <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-soft transition-colors group-hover:bg-emerald-accent/15">
                <stat.icon className="h-5 w-5 text-emerald-accent" />
              </div>
              <span className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                {stat.value}
              </span>
              <span className="mt-0.5 text-xs font-semibold text-foreground sm:text-sm">
                {stat.label}
              </span>
              <span className="mt-0.5 text-[11px] text-muted-foreground sm:text-xs">
                {stat.description}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}