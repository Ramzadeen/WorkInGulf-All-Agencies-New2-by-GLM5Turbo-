"use client";

import type { Sector } from "@/lib/types";
import { ALL_SECTORS } from "@/lib/types";
import { cn } from "@/lib/utils";

const sectorIcons: Record<string, string> = {
  "All Sectors": "🔍",
  Hospitality: "🏨",
  Healthcare: "🏥",
  "IT & Tech": "💻",
  Construction: "🏗️",
  Retail: "🛒",
  Manufacturing: "🏭",
  Education: "📚",
  "Domestic Work": "🏠",
  Logistics: "🚛",
  Engineering: "⚙️",
  Finance: "💰",
  Agriculture: "🌾",
};

interface SectorFiltersProps {
  activeSector: Sector | "All";
  onSectorChange: (sector: Sector | "All") => void;
  availableSectors: Sector[];
}

export function SectorFilters({
  activeSector,
  onSectorChange,
  availableSectors,
}: SectorFiltersProps) {
  // Only show sectors that have agencies, plus "All"
  const displaySectors = ["All Sectors" as const].concat(
    ALL_SECTORS.filter((s) => availableSectors.includes(s))
  );

  return (
    <div className="mx-auto max-w-7xl px-4 pt-8 sm:px-6 lg:px-8">
      <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
        <span className="shrink-0 text-sm font-medium text-muted-foreground">
          Filter:
        </span>
        <div className="flex gap-2">
          {displaySectors.map((sector) => {
            const value = sector === "All Sectors" ? "All" : sector;
            const isActive = activeSector === value;
            return (
              <button
                key={sector}
                onClick={() => onSectorChange(value as Sector | "All")}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200",
                  isActive
                    ? "border-emerald-accent bg-emerald-accent text-white shadow-md shadow-emerald-accent/25"
                    : "border-border bg-card text-muted-foreground hover:border-emerald-accent/50 hover:text-foreground"
                )}
                aria-pressed={isActive}
              >
                <span className="text-sm" role="img" aria-hidden="true">
                  {sectorIcons[sector] || "📌"}
                </span>
                {sector}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}