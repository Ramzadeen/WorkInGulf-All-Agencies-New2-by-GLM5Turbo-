import {
  Search,
  FileCheck,
  Plane,
  Briefcase,
} from "lucide-react";

const steps = [
  {
    icon: Search,
    step: "01",
    title: "Search & Compare",
    description:
      "Browse our verified directory of SLBFE-licensed agencies. Filter by sector, location, or ratings to find the perfect match for your skills and career goals.",
  },
  {
    icon: FileCheck,
    step: "02",
    title: "Verify & Contact",
    description:
      "Every agency's license status is verified against the official SLBFE registry. Review ratings from real workers, then contact agencies directly through our platform.",
  },
  {
    icon: Briefcase,
    step: "03",
    title: "Apply & Prepare",
    description:
      "Submit your application through the agency. Prepare your documents using our checklist and get tips on interview preparation and what to expect.",
  },
  {
    icon: Plane,
    step: "04",
    title: "Travel & Work",
    description:
      "Once approved, complete your pre-departure training and travel to your new role with confidence. We provide ongoing support resources for Sri Lankan workers abroad.",
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-muted/50 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-wider text-emerald-accent">
            Simple Process
          </span>
          <h2 className="mt-2 text-2xl font-bold text-foreground sm:text-3xl">
            How WorkinGulf Works
          </h2>
          <p className="mt-3 text-sm text-muted-foreground sm:text-base">
            Four simple steps to find safe, verified overseas employment
            through Sri Lankan government-licensed agencies.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, i) => (
            <div key={step.step} className="group relative">
              {/* Connector line (not on last item) */}
              {i < steps.length - 1 && (
                <div className="absolute right-0 top-10 hidden h-px w-full translate-x-1/2 bg-gradient-to-r from-border to-transparent lg:block" />
              )}

              <div className="rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:border-emerald-accent/20 hover:shadow-lg hover:shadow-emerald-accent/5">
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-soft transition-colors group-hover:bg-emerald-accent group-hover:text-white">
                    <step.icon className="h-6 w-6 text-emerald-accent transition-colors group-hover:text-white" />
                  </div>
                  <span className="text-3xl font-bold text-muted-foreground/20">
                    {step.step}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-foreground">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}