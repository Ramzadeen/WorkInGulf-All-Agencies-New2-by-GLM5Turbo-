"use client";

import { useState, useCallback } from "react";
import { Search, Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface HeroProps {
  onSearch: (query: string) => void;
  resultCount: number;
}

export function Hero({ onSearch, resultCount }: HeroProps) {
  const [query, setQuery] = useState("");

  const handleSearch = useCallback(() => {
    onSearch(query);
  }, [query, onSearch]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleSearch();
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-navy via-navy-light to-navy">
      {/* Background decoration */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -right-40 -top-40 h-96 w-96 rounded-full bg-emerald-accent/5 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-emerald-accent/5 blur-3xl" />
        <div className="absolute right-1/4 top-1/3 h-2 w-2 rounded-full bg-emerald-accent/30" />
        <div className="absolute left-1/3 top-1/4 h-1.5 w-1.5 rounded-full bg-emerald-accent/20" />
        <div className="absolute right-1/3 bottom-1/3 h-1 w-1 rounded-full bg-emerald-accent/25" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28 lg:px-8 lg:py-36">
        <div className="mx-auto max-w-3xl text-center">
          {/* Badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-accent/20 bg-emerald-accent/10 px-4 py-1.5 text-sm text-emerald-accent">
            <Sparkles className="h-3.5 w-3.5" />
            <span>SLBFE-Verified Directory</span>
          </div>

          {/* Heading */}
          <h1 className="text-3xl font-bold leading-tight tracking-tight text-navy-foreground sm:text-4xl lg:text-5xl xl:text-6xl">
            Find Registered{" "}
            <span className="text-emerald-accent">Sri Lankan</span>
            <br className="hidden sm:block" /> Employment Agencies
          </h1>

          {/* Subheading */}
          <p className="mx-auto mt-5 max-w-xl text-base text-navy-foreground/60 sm:text-lg">
            Your trusted directory for safe, verified overseas employment
            opportunities. Every agency is checked against the official SLBFE registry.
          </p>

          {/* Search Bar */}
          <div className="mx-auto mt-8 flex max-w-2xl overflow-hidden rounded-xl border border-white/10 bg-white/5 shadow-2xl shadow-black/20 backdrop-blur-sm">
            <div className="flex flex-1 items-center gap-2 px-4">
              <Search className="h-5 w-5 text-navy-foreground/40" />
              <Input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Search by agency name, city, or license number..."
                className="h-12 border-0 bg-transparent text-navy-foreground placeholder:text-navy-foreground/40 focus-visible:ring-0"
                aria-label="Search agencies"
              />
            </div>
            <Button
              onClick={handleSearch}
              className="m-1 h-10 rounded-lg bg-emerald-accent px-6 text-sm font-semibold text-white hover:bg-emerald-hover"
            >
              Search
            </Button>
          </div>

          {/* Quick stats under search */}
          <p className="mt-4 text-xs text-navy-foreground/40">
            {resultCount > 0 ? (
              <span>
                Showing <strong className="text-emerald-accent">{resultCount}</strong> verified agencies
              </span>
            ) : (
              <span>Try &quot;Colombo&quot;, &quot;Hospitality&quot;, or a license number like &quot;4500&quot;</span>
            )}
          </p>
        </div>
      </div>
    </section>
  );
}