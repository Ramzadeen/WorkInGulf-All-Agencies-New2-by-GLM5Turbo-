"use client";

import { useMemo } from "react";
import { AlertCircle, SearchX } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { AgencyCard } from "./AgencyCard";
import type { Agency, Sector } from "@/lib/types";

interface AgencyGridProps {
  agencies: Agency[];
  isLoading: boolean;
  activeSector: Sector | "All";
  searchQuery: string;
}

function AgencyCardSkeleton() {
  return (
    <div className="rounded-xl border border-border/60 bg-card p-5">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <Skeleton className="h-11 w-11 rounded-xl" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-36" />
            <Skeleton className="h-3 w-24" />
          </div>
        </div>
        <Skeleton className="h-6 w-20 rounded-full" />
      </div>
      <div className="mt-4 space-y-3">
        <Skeleton className="h-4 w-40" />
        <Skeleton className="h-3.5 w-32" />
        <div className="flex gap-1.5">
          <Skeleton className="h-5 w-20 rounded-md" />
          <Skeleton className="h-5 w-24 rounded-md" />
        </div>
        <Skeleton className="h-3.5 w-32" />
      </div>
      <div className="mt-4 flex gap-2 border-t border-border/50 pt-3">
        <Skeleton className="h-9 flex-1 rounded-md" />
        <Skeleton className="h-9 w-9 rounded-md" />
        <Skeleton className="h-9 w-9 rounded-md" />
      </div>
    </div>
  );
}

export function AgencyGrid({
  agencies,
  isLoading,
  activeSector,
  searchQuery,
}: AgencyGridProps) {
  const filteredAgencies = useMemo(() => {
    if (isLoading) return [];
    let result = agencies;

    if (activeSector !== "All") {
      result = result.filter((a) => a.sectors.includes(activeSector as Sector));
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (a) =>
          a.name.toLowerCase().includes(q) ||
          a.city.toLowerCase().includes(q) ||
          a.licenseNo.toLowerCase().includes(q)
      );
    }

    return result;
  }, [agencies, activeSector, searchQuery, isLoading]);

  const isFiltering = activeSector !== "All" || searchQuery.length > 0;

  if (isLoading) {
    return (
      <section id="agencies" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <h2 className="mb-6 text-2xl font-bold text-foreground">
          Featured Agencies
        </h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <AgencyCardSkeleton key={i} />
          ))}
        </div>
      </section>
    );
  }

  return (
    <section id="agencies" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground sm:text-3xl">
            Featured Agencies
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {isFiltering
              ? `${filteredAgencies.length} result${filteredAgencies.length !== 1 ? "s" : ""} found`
              : `${agencies.length} SLBFE-verified agencies in our directory`}
          </p>
        </div>
        {isFiltering && (
          <button
            onClick={() => window.location.reload()}
            className="text-xs font-medium text-emerald-accent hover:underline"
          >
            Clear all filters
          </button>
        )}
      </div>

      {filteredAgencies.length === 0 ? (
        <div className="mt-12 flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16 text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
            {searchQuery ? (
              <SearchX className="h-7 w-7 text-muted-foreground" />
            ) : (
              <AlertCircle className="h-7 w-7 text-muted-foreground" />
            )}
          </div>
          <h3 className="text-base font-semibold text-foreground">
            No agencies found
          </h3>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground">
            {searchQuery
              ? `No results for "${searchQuery}". Try a different search term or clear filters.`
              : `No agencies in the "${activeSector}" sector yet. Check back soon.`}
          </p>
        </div>
      ) : (
        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredAgencies.map((agency, index) => (
            <AgencyCard key={agency.id} agency={agency} index={index} />
          ))}
        </div>
      )}
    </section>
  );
}