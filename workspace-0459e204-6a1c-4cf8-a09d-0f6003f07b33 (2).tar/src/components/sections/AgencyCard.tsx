"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Star,
  MapPin,
  Briefcase,
  ExternalLink,
  Phone,
  Mail,
  ShieldCheck,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import type { Agency, Sector } from "@/lib/types";

interface AgencyCardProps {
  agency: Agency;
  index: number;
}

function StarRating({ rating, count }: { rating: number; count: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-3.5 w-3.5 ${
              star <= Math.round(rating)
                ? "fill-amber-400 text-amber-400"
                : "fill-muted text-muted"
            }`}
          />
        ))}
      </div>
      <span className="text-xs font-medium text-foreground">{rating}</span>
      <span className="text-xs text-muted-foreground">({count})</span>
    </div>
  );
}

const sectorColors: Record<Sector, string> = {
  Hospitality: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  Healthcare: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300",
  "IT & Tech": "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300",
  Construction: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  Retail: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
  Manufacturing: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  Education: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300",
  "Domestic Work": "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300",
  Logistics: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300",
  Engineering: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300",
  Finance: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
  Agriculture: "bg-lime-100 text-lime-700 dark:bg-lime-900/30 dark:text-lime-300",
};

export function AgencyCard({ agency, index }: AgencyCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      <Card
        className="group relative overflow-hidden border-border/60 bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-emerald-accent/5 hover:border-emerald-accent/20"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              {/* Agency avatar */}
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-soft text-sm font-bold text-emerald-accent">
                {agency.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <h3 className="truncate text-base font-semibold leading-tight text-foreground">
                  {agency.name}
                </h3>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  License: {agency.licenseNo}
                </p>
              </div>
            </div>
            {agency.isVerified && (
              <Badge
                variant="secondary"
                className="shrink-0 gap-1 bg-emerald-soft text-emerald-accent text-[11px] font-semibold"
              >
                <ShieldCheck className="h-3 w-3" />
                Verified
              </Badge>
            )}
          </div>
        </CardHeader>

        <CardContent className="space-y-3 pb-3">
          {/* Rating */}
          <StarRating rating={agency.rating} count={agency.reviewCount} />

          {/* Location */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 shrink-0 text-emerald-accent/70" />
            <span>{agency.city}</span>
            {agency.foundedYear && (
              <>
                <span className="text-border">|</span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  Est. {agency.foundedYear}
                </span>
              </>
            )}
          </div>

          {/* Description */}
          {isHovered && agency.description && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="text-xs leading-relaxed text-muted-foreground line-clamp-2"
            >
              {agency.description}
            </motion.p>
          )}

          {/* Sectors */}
          <div className="flex flex-wrap gap-1.5">
            {agency.sectors.map((sector: Sector) => (
              <span
                key={sector}
                className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-medium ${
                  sectorColors[sector] || "bg-muted text-muted-foreground"
                }`}
              >
                <Briefcase className="h-3 w-3" />
                {sector}
              </span>
            ))}
          </div>

          {/* Vacancy count */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-accent" />
            <span>{agency.vacancyCount} active vacancies</span>
          </div>
        </CardContent>

        <CardFooter className="gap-2 border-t border-border/50 bg-muted/30 pt-3">
          <Button
            size="sm"
            className="flex-1 bg-emerald-accent text-white hover:bg-emerald-hover"
          >
            View Vacancies
            <ExternalLink className="ml-1.5 h-3.5 w-3.5" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 border-border hover:bg-muted"
            aria-label={`Call ${agency.name}`}
          >
            <Phone className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0 border-border hover:bg-muted"
            aria-label={`Email ${agency.name}`}
          >
            <Mail className="h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}