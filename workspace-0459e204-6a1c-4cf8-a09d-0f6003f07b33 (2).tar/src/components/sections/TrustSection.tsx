import {
  ShieldCheck,
  FileText,
  AlertTriangle,
  HeartHandshake,
} from "lucide-react";

const features = [
  {
    icon: ShieldCheck,
    title: "SLBFE License Verification",
    description:
      "Every agency listed on WorkinGulf is cross-verified against the Sri Lanka Bureau of Foreign Employment's official registry. We update our records monthly to ensure no expired or revoked licenses appear in our directory.",
  },
  {
    icon: FileText,
    title: "Transparent Agency Profiles",
    description:
      "Each agency profile includes license number, sectors of specialization, city location, and user reviews. We believe in full transparency so you can make informed decisions about your career and safety.",
  },
  {
    icon: AlertTriangle,
    title: "Fraud Protection Resources",
    description:
      "Access our comprehensive guides on recognizing recruitment fraud, understanding your rights as a migrant worker, and reporting suspicious agencies to SLBFE and foreign employment authorities.",
  },
  {
    icon: HeartHandshake,
    title: "Worker Support Network",
    description:
      "Connect with fellow Sri Lankan workers already employed in Gulf countries through our community forums. Get first-hand advice on living conditions, employer expectations, and cultural tips.",
  },
];

export function TrustSection() {
  return (
    <section className="bg-muted/50 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-semibold uppercase tracking-wider text-emerald-accent">
            Why WorkinGulf
          </span>
          <h2 className="mt-2 text-2xl font-bold text-foreground sm:text-3xl">
            Your Safety Comes First
          </h2>
          <p className="mt-3 text-sm text-muted-foreground sm:text-base">
            We go beyond a simple directory. WorkinGulf is committed to
            protecting Sri Lankan workers from fraud and ensuring every
            overseas placement is legitimate.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:gap-8 md:grid-cols-2">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group flex gap-4 rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:border-emerald-accent/20 hover:shadow-lg hover:shadow-emerald-accent/5"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-soft transition-colors group-hover:bg-emerald-accent">
                <feature.icon className="h-6 w-6 text-emerald-accent transition-colors group-hover:text-white" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-foreground">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}