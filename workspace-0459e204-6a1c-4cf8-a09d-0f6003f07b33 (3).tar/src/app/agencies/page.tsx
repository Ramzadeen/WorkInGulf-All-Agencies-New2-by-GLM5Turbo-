"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import Link from "next/link";
import {
  Search,
  SlidersHorizontal,
  LayoutGrid,
  List,
  X,
  Star,
  MapPin,
  Building2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  PaginationEllipsis,
} from "@/components/ui/pagination";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { AgencyCard } from "@/components/sections/AgencyCard";
import { cn } from "@/lib/utils";
import type { Agency, Sector } from "@/lib/types";

// ─── Constants ───────────────────────────────────────────────────────
const ITEMS_PER_PAGE = 12;

type SortOption = "highest-rated" | "most-vacancies" | "newest" | "a-z";
type ViewMode = "grid" | "list";

// ─── List View Card ──────────────────────────────────────────────────
function AgencyListCard({ agency }: { agency: Agency }) {
  return (
    <div className="flex flex-col gap-4 rounded-xl border border-border/60 bg-card p-4 transition-colors hover:border-emerald-accent/20 sm:flex-row sm:items-center sm:gap-6 sm:p-5">
      {/* Avatar */}
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-soft text-base font-bold text-emerald-accent">
        {agency.name.charAt(0)}
      </div>

      {/* Info */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <h3 className="truncate text-sm font-semibold text-foreground">
            {agency.name}
          </h3>
          {agency.isVerified && (
            <Badge className="shrink-0 gap-1 bg-emerald-soft text-emerald-accent text-[10px] font-semibold px-1.5 py-0">
              Verified
            </Badge>
          )}
        </div>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <MapPin className="h-3 w-3 text-emerald-accent/70" />
            {agency.city}
          </span>
          <span className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
            {agency.rating} ({agency.reviewCount})
          </span>
          <span>{agency.vacancyCount} vacancies</span>
        </div>
        <div className="mt-1.5 flex flex-wrap gap-1">
          {agency.sectors.slice(0, 3).map((s: string) => (
            <span
              key={s}
              className="rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground"
            >
              {s}
            </span>
          ))}
          {agency.sectors.length > 3 && (
            <span className="text-[10px] text-muted-foreground">
              +{agency.sectors.length - 3} more
            </span>
          )}
        </div>
      </div>

      {/* CTA */}
      <Button
        size="sm"
        className="shrink-0 bg-emerald-accent text-white hover:bg-emerald-hover"
      >
        View Vacancies
      </Button>
    </div>
  );
}

// ─── Filter Sidebar Content (shared between desktop & mobile) ────────
function FilterSidebarContent({
  sectors,
  cities,
  allAgencies,
  selectedSectors,
  toggleSector,
  selectedCities,
  toggleCity,
  minRating,
  setMinRating,
  clearFilters,
  activeFilterCount,
}: {
  sectors: Sector[];
  cities: string[];
  allAgencies: Agency[];
  selectedSectors: Set<string>;
  toggleSector: (s: string) => void;
  selectedCities: Set<string>;
  toggleCity: (c: string) => void;
  minRating: number | null;
  setMinRating: (r: number | null) => void;
  clearFilters: () => void;
  activeFilterCount: number;
}) {
  // Count agencies per sector
  const sectorCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    sectors.forEach((s) => (counts[s] = 0));
    allAgencies.forEach((a) =>
      a.sectors.forEach((s) => {
        if (counts[s] !== undefined) counts[s]++;
      })
    );
    return counts;
  }, [sectors, allAgencies]);

  // Count agencies per city
  const cityCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    cities.forEach((c) => (counts[c] = 0));
    allAgencies.forEach((a) => {
      if (counts[a.city] !== undefined) counts[a.city]++;
    });
    return counts;
  }, [cities, allAgencies]);

  return (
    <div className="space-y-6">
      {/* Header with clear */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">Filters</h2>
        {activeFilterCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="h-auto gap-1 p-0 text-xs text-muted-foreground hover:text-foreground"
          >
            <X className="h-3 w-3" />
            Clear Filters ({activeFilterCount})
          </Button>
        )}
      </div>

      {/* Sector Filter */}
      <div>
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Sector
        </h3>
        <div className="agency-scroll max-h-56 space-y-2 overflow-y-auto pr-1">
          {sectors.map((sector) => (
            <label
              key={sector}
              className="flex cursor-pointer items-center gap-2.5 rounded-md px-1.5 py-1 transition-colors hover:bg-muted/60"
            >
              <Checkbox
                checked={selectedSectors.has(sector)}
                onCheckedChange={() => toggleSector(sector)}
                aria-label={`Filter by ${sector}`}
              />
              <span className="flex-1 text-sm text-foreground">{sector}</span>
              <Badge
                variant="secondary"
                className={cn(
                  "h-5 min-w-5 justify-center rounded-full px-1.5 text-[10px] font-semibold",
                  selectedSectors.has(sector)
                    ? "bg-emerald-soft text-emerald-accent"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {sectorCounts[sector] ?? 0}
              </Badge>
            </label>
          ))}
        </div>
      </div>

      {/* City Filter */}
      <div>
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          City
        </h3>
        <div className="agency-scroll max-h-48 space-y-2 overflow-y-auto pr-1">
          {cities.map((city) => (
            <label
              key={city}
              className="flex cursor-pointer items-center gap-2.5 rounded-md px-1.5 py-1 transition-colors hover:bg-muted/60"
            >
              <Checkbox
                checked={selectedCities.has(city)}
                onCheckedChange={() => toggleCity(city)}
                aria-label={`Filter by ${city}`}
              />
              <span className="flex-1 text-sm text-foreground">{city}</span>
              <Badge
                variant="secondary"
                className={cn(
                  "h-5 min-w-5 justify-center rounded-full px-1.5 text-[10px] font-semibold",
                  selectedCities.has(city)
                    ? "bg-emerald-soft text-emerald-accent"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {cityCounts[city] ?? 0}
              </Badge>
            </label>
          ))}
        </div>
      </div>

      {/* Rating Filter */}
      <div>
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Minimum Rating
        </h3>
        <div className="flex flex-wrap gap-2">
          {[4, 3, 2].map((rating) => (
            <Button
              key={rating}
              variant={minRating === rating ? "default" : "outline"}
              size="sm"
              onClick={() => setMinRating(minRating === rating ? null : rating)}
              className={cn(
                "gap-1.5 text-xs",
                minRating === rating
                  ? "bg-emerald-accent text-white hover:bg-emerald-hover"
                  : "hover:border-emerald-accent/40"
              )}
            >
              {rating}+
              <Star className="h-3 w-3" />
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Main Page Component ─────────────────────────────────────────────
export default function AgenciesPage() {
  // Data state
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [sectors, setSectors] = useState<Sector[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSearch, setActiveSearch] = useState("");
  const [selectedSectors, setSelectedSectors] = useState<Set<string>>(new Set());
  const [selectedCities, setSelectedCities] = useState<Set<string>>(new Set());
  const [minRating, setMinRating] = useState<number | null>(null);

  // UI state
  const [sort, setSort] = useState<SortOption>("highest-rated");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [currentPage, setCurrentPage] = useState(1);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Fetch data
  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);
        const res = await fetch("/api/agencies?limit=200");
        const data = await res.json();
        setAgencies(data.agencies || []);
        setSectors(data.sectors || []);
        setCities(data.cities || []);
      } catch (err) {
        console.error("Failed to fetch agencies:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Filter & sort
  const filteredAgencies = useMemo(() => {
    let result = [...agencies];

    // Search
    if (activeSearch) {
      const q = activeSearch.toLowerCase();
      result = result.filter(
        (a) =>
          a.name.toLowerCase().includes(q) ||
          a.city.toLowerCase().includes(q) ||
          a.licenseNo.toLowerCase().includes(q)
      );
    }

    // Sector filter
    if (selectedSectors.size > 0) {
      result = result.filter((a) =>
        a.sectors.some((s) => selectedSectors.has(s))
      );
    }

    // City filter
    if (selectedCities.size > 0) {
      result = result.filter((a) => selectedCities.has(a.city));
    }

    // Rating filter
    if (minRating !== null) {
      result = result.filter((a) => a.rating >= minRating);
    }

    // Sort
    switch (sort) {
      case "highest-rated":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "most-vacancies":
        result.sort((a, b) => b.vacancyCount - a.vacancyCount);
        break;
      case "newest":
        result.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        break;
      case "a-z":
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    return result;
  }, [agencies, activeSearch, selectedSectors, selectedCities, minRating, sort]);

  // Pagination
  const totalPages = Math.ceil(filteredAgencies.length / ITEMS_PER_PAGE);
  const paginatedAgencies = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredAgencies.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredAgencies, currentPage]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [activeSearch, selectedSectors, selectedCities, minRating, sort]);

  // Handlers
  const handleSearch = useCallback(() => {
    setActiveSearch(searchQuery);
  }, [searchQuery]);

  const handleSearchKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === "Enter") handleSearch();
    },
    [handleSearch]
  );

  const toggleSector = useCallback((s: string) => {
    setSelectedSectors((prev) => {
      const next = new Set(prev);
      if (next.has(s)) next.delete(s);
      else next.add(s);
      return next;
    });
  }, []);

  const toggleCity = useCallback((c: string) => {
    setSelectedCities((prev) => {
      const next = new Set(prev);
      if (next.has(c)) next.delete(c);
      else next.add(c);
      return next;
    });
  }, []);

  const clearFilters = useCallback(() => {
    setSelectedSectors(new Set());
    setSelectedCities(new Set());
    setMinRating(null);
    setActiveSearch("");
    setSearchQuery("");
  }, []);

  const activeFilterCount =
    selectedSectors.size + selectedCities.size + (minRating !== null ? 1 : 0) + (activeSearch ? 1 : 0);

  // Generate page numbers for pagination
  const pageNumbers = useMemo(() => {
    const pages: (number | "ellipsis")[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (currentPage > 3) pages.push("ellipsis");
      const start = Math.max(2, currentPage - 1);
      const end = Math.min(totalPages - 1, currentPage + 1);
      for (let i = start; i <= end; i++) pages.push(i);
      if (currentPage < totalPages - 2) pages.push("ellipsis");
      pages.push(totalPages);
    }
    return pages;
  }, [totalPages, currentPage]);

  // ─── Render ─────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        {/* ── Page Header Banner ────────────────────────────────────── */}
        <section className="relative overflow-hidden bg-gradient-to-br from-navy via-navy-light to-navy">
          {/* Background decoration */}
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute -right-32 -top-32 h-72 w-72 rounded-full bg-emerald-accent/5 blur-3xl" />
            <div className="absolute -bottom-32 -left-32 h-72 w-72 rounded-full bg-emerald-accent/5 blur-3xl" />
          </div>

          <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
            {/* Breadcrumb */}
            <Breadcrumb className="mb-4">
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink
                    asChild
                    className="text-navy-foreground/50 hover:text-navy-foreground"
                  >
                    <Link href="/">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="text-navy-foreground/30">
                  <ChevronRightIcon />
                </BreadcrumbSeparator>
                <BreadcrumbItem>
                  <BreadcrumbPage className="text-navy-foreground/80">
                    Agencies
                  </BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>

            {/* Title */}
            <div className="max-w-2xl">
              <h1 className="text-2xl font-bold leading-tight tracking-tight text-navy-foreground sm:text-3xl">
                All Employment Agencies
              </h1>
              <p className="mt-2 text-sm text-navy-foreground/60 sm:text-base">
                Browse our complete directory of SLBFE-verified agencies
              </p>
            </div>

            {/* Search Bar */}
            <div className="mx-auto mt-6 flex max-w-xl overflow-hidden rounded-xl border border-white/10 bg-white/5 shadow-2xl shadow-black/20 backdrop-blur-sm">
              <div className="flex flex-1 items-center gap-2 px-4">
                <Search className="h-4 w-4 text-navy-foreground/40" />
                <Input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={handleSearchKeyDown}
                  placeholder="Search agencies by name, city, or license..."
                  className="h-10 border-0 bg-transparent text-sm text-navy-foreground placeholder:text-navy-foreground/40 focus-visible:ring-0"
                  aria-label="Search agencies"
                />
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery("");
                      setActiveSearch("");
                    }}
                    className="text-navy-foreground/40 hover:text-navy-foreground/70"
                    aria-label="Clear search"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <Button
                onClick={handleSearch}
                className="m-1 h-8 rounded-lg bg-emerald-accent px-4 text-xs font-semibold text-white hover:bg-emerald-hover"
              >
                Search
              </Button>
            </div>
          </div>
        </section>

        {/* ── Content Area ──────────────────────────────────────────── */}
        <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          {/* Mobile Filter Toggle */}
          <div className="mb-4 flex items-center justify-between lg:hidden">
            <Sheet
              open={mobileFilterOpen}
              onOpenChange={setMobileFilterOpen}
            >
              <SheetTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                  {activeFilterCount > 0 && (
                    <Badge className="ml-1 h-5 min-w-5 justify-center rounded-full bg-emerald-soft px-1.5 text-[10px] font-semibold text-emerald-accent">
                      {activeFilterCount}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 overflow-y-auto p-6">
                <SheetTitle className="sr-only">Filter Agencies</SheetTitle>
                <FilterSidebarContent
                  sectors={sectors}
                  cities={cities}
                  allAgencies={agencies}
                  selectedSectors={selectedSectors}
                  toggleSector={toggleSector}
                  selectedCities={selectedCities}
                  toggleCity={toggleCity}
                  minRating={minRating}
                  setMinRating={setMinRating}
                  clearFilters={() => {
                    clearFilters();
                    setMobileFilterOpen(false);
                  }}
                  activeFilterCount={activeFilterCount}
                />
              </SheetContent>
            </Sheet>

            <span className="text-sm text-muted-foreground">
              {loading ? (
                <Skeleton className="inline-block h-5 w-32" />
              ) : (
                <>
                  <span className="font-medium text-foreground">
                    {filteredAgencies.length}
                  </span>{" "}
                  agencies found
                </>
              )}
            </span>
          </div>

          <div className="flex gap-8">
            {/* ── Desktop Sidebar ───────────────────────────────────── */}
            <aside className="hidden w-64 shrink-0 lg:block">
              <div className="sticky top-24 rounded-xl border border-border/60 bg-card p-5">
                <FilterSidebarContent
                  sectors={sectors}
                  cities={cities}
                  allAgencies={agencies}
                  selectedSectors={selectedSectors}
                  toggleSector={toggleSector}
                  selectedCities={selectedCities}
                  toggleCity={toggleCity}
                  minRating={minRating}
                  setMinRating={setMinRating}
                  clearFilters={clearFilters}
                  activeFilterCount={activeFilterCount}
                />
              </div>
            </aside>

            {/* ── Main Content ──────────────────────────────────────── */}
            <div className="min-w-0 flex-1">
              {/* Sort Bar */}
              <div className="mb-6 hidden items-center justify-between lg:flex">
                <p className="text-sm text-muted-foreground">
                  {loading ? (
                    <Skeleton className="inline-block h-5 w-48" />
                  ) : (
                    <>
                      Showing{" "}
                      <span className="font-medium text-foreground">
                        {filteredAgencies.length}
                      </span>{" "}
                      {filteredAgencies.length === 1 ? "agency" : "agencies"}
                    </>
                  )}
                </p>

                <div className="flex items-center gap-3">
                  {/* Sort Dropdown */}
                  <Select
                    value={sort}
                    onValueChange={(v) => setSort(v as SortOption)}
                  >
                    <SelectTrigger className="h-9 w-[160px] text-xs">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="highest-rated">
                        Highest Rated
                      </SelectItem>
                      <SelectItem value="most-vacancies">
                        Most Vacancies
                      </SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="a-z">A-Z</SelectItem>
                    </SelectContent>
                  </Select>

                  {/* View Toggle */}
                  <div className="flex rounded-lg border border-border p-0.5">
                    <Button
                      variant="ghost"
                      size="icon"
                      className={cn(
                        "h-8 w-8 rounded-md p-0",
                        viewMode === "grid"
                          ? "bg-muted text-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      )}
                      onClick={() => setViewMode("grid")}
                      aria-label="Grid view"
                    >
                      <LayoutGrid className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className={cn(
                        "h-8 w-8 rounded-md p-0",
                        viewMode === "list"
                          ? "bg-muted text-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      )}
                      onClick={() => setViewMode("list")}
                      aria-label="List view"
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Mobile Sort Bar */}
              <div className="mb-4 flex items-center justify-between lg:hidden">
                <Select
                  value={sort}
                  onValueChange={(v) => setSort(v as SortOption)}
                >
                  <SelectTrigger className="h-8 w-[140px] text-xs">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="highest-rated">Highest Rated</SelectItem>
                    <SelectItem value="most-vacancies">
                      Most Vacancies
                    </SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="a-z">A-Z</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex rounded-lg border border-border p-0.5">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={cn(
                      "h-7 w-7 rounded-md p-0",
                      viewMode === "grid"
                        ? "bg-muted text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                    onClick={() => setViewMode("grid")}
                    aria-label="Grid view"
                  >
                    <LayoutGrid className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={cn(
                      "h-7 w-7 rounded-md p-0",
                      viewMode === "list"
                        ? "bg-muted text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                    onClick={() => setViewMode("list")}
                    aria-label="List view"
                  >
                    <List className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>

              {/* Active Filter Tags */}
              {activeFilterCount > 0 && (
                <div className="mb-4 flex flex-wrap items-center gap-2">
                  {activeSearch && (
                    <Badge
                      variant="secondary"
                      className="gap-1 bg-emerald-soft text-emerald-accent text-xs"
                    >
                      <Search className="h-3 w-3" />
                      &quot;{activeSearch}&quot;
                      <button
                        onClick={() => {
                          setActiveSearch("");
                          setSearchQuery("");
                        }}
                        aria-label="Remove search filter"
                      >
                        <X className="ml-1 h-3 w-3 cursor-pointer" />
                      </button>
                    </Badge>
                  )}
                  {Array.from(selectedSectors).map((s) => (
                    <Badge
                      key={s}
                      variant="secondary"
                      className="gap-1 bg-emerald-soft text-emerald-accent text-xs"
                    >
                      <Building2 className="h-3 w-3" />
                      {s}
                      <button
                        onClick={() => toggleSector(s)}
                        aria-label={`Remove ${s} filter`}
                      >
                        <X className="ml-1 h-3 w-3 cursor-pointer" />
                      </button>
                    </Badge>
                  ))}
                  {Array.from(selectedCities).map((c) => (
                    <Badge
                      key={c}
                      variant="secondary"
                      className="gap-1 bg-emerald-soft text-emerald-accent text-xs"
                    >
                      <MapPin className="h-3 w-3" />
                      {c}
                      <button
                        onClick={() => toggleCity(c)}
                        aria-label={`Remove ${c} filter`}
                      >
                        <X className="ml-1 h-3 w-3 cursor-pointer" />
                      </button>
                    </Badge>
                  ))}
                  {minRating !== null && (
                    <Badge
                      variant="secondary"
                      className="gap-1 bg-emerald-soft text-emerald-accent text-xs"
                    >
                      <Star className="h-3 w-3" />
                      {minRating}+ Stars
                      <button
                        onClick={() => setMinRating(null)}
                        aria-label="Remove rating filter"
                      >
                        <X className="ml-1 h-3 w-3 cursor-pointer" />
                      </button>
                    </Badge>
                  )}
                </div>
              )}

              {/* Loading Skeletons */}
              {loading && (
                <div
                  className={
                    viewMode === "grid"
                      ? "grid gap-4 sm:grid-cols-2 xl:grid-cols-3"
                      : "flex flex-col gap-3"
                  }
                >
                  {Array.from({ length: 6 }).map((_, i) =>
                    viewMode === "grid" ? (
                      <div
                        key={i}
                        className="rounded-xl border border-border/60 p-5"
                      >
                        <div className="flex items-start gap-3">
                          <Skeleton className="h-11 w-11 rounded-xl" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-3 w-1/2" />
                          </div>
                        </div>
                        <div className="mt-4 space-y-2">
                          <Skeleton className="h-3 w-full" />
                          <Skeleton className="h-3 w-2/3" />
                          <Skeleton className="h-6 w-20" />
                        </div>
                        <div className="mt-4 flex gap-2">
                          <Skeleton className="h-8 flex-1 rounded-lg" />
                          <Skeleton className="h-8 w-8 rounded-lg" />
                          <Skeleton className="h-8 w-8 rounded-lg" />
                        </div>
                      </div>
                    ) : (
                      <div
                        key={i}
                        className="flex items-center gap-4 rounded-xl border border-border/60 p-4 sm:flex-row"
                      >
                        <Skeleton className="h-12 w-12 rounded-xl" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-1/3" />
                          <Skeleton className="h-3 w-2/5" />
                        </div>
                        <Skeleton className="h-8 w-28 rounded-lg" />
                      </div>
                    )
                  )}
                </div>
              )}

              {/* Empty State */}
              {!loading && filteredAgencies.length === 0 && (
                <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border/80 py-16 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted">
                    <Search className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="mt-4 text-base font-semibold text-foreground">
                    No agencies found
                  </h3>
                  <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                    {activeFilterCount > 0
                      ? "Try adjusting your filters or search terms to find what you're looking for."
                      : "No agencies match your criteria. Please try again."}
                  </p>
                  {activeFilterCount > 0 && (
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={clearFilters}
                    >
                      Clear All Filters
                    </Button>
                  )}
                </div>
              )}

              {/* Agency Cards Grid / List */}
              {!loading && filteredAgencies.length > 0 && (
                <>
                  {viewMode === "grid" ? (
                    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                      {paginatedAgencies.map((agency, idx) => (
                        <AgencyCard
                          key={agency.id}
                          agency={agency}
                          index={idx}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-3">
                      {paginatedAgencies.map((agency) => (
                        <AgencyListCard key={agency.id} agency={agency} />
                      ))}
                    </div>
                  )}

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <Pagination className="mt-10">
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (currentPage > 1) setCurrentPage((p) => p - 1);
                            }}
                            className={cn(
                              "gap-1 text-xs",
                              currentPage <= 1 &&
                                "pointer-events-none opacity-40"
                            )}
                            aria-disabled={currentPage <= 1}
                          />
                        </PaginationItem>

                        {pageNumbers.map((page, idx) =>
                          page === "ellipsis" ? (
                            <PaginationItem key={`ellipsis-${idx}`}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          ) : (
                            <PaginationItem key={page}>
                              <PaginationLink
                                href="#"
                                isActive={currentPage === page}
                                onClick={(e) => {
                                  e.preventDefault();
                                  setCurrentPage(page as number);
                                }}
                                className="text-xs"
                              >
                                {page}
                              </PaginationLink>
                            </PaginationItem>
                          )
                        )}

                        <PaginationItem>
                          <PaginationNext
                            href="#"
                            onClick={(e) => {
                              e.preventDefault();
                              if (currentPage < totalPages)
                                setCurrentPage((p) => p + 1);
                            }}
                            className={cn(
                              "gap-1 text-xs",
                              currentPage >= totalPages &&
                                "pointer-events-none opacity-40"
                            )}
                            aria-disabled={currentPage >= totalPages}
                          />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  )}
                </>
              )}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

// Small chevron for breadcrumb separator (using native SVG to match the pattern)
function ChevronRightIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  );
}