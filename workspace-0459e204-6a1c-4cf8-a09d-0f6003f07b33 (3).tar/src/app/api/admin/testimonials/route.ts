import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

async function checkAuth() {
  const cookieStore = await cookies();
  return cookieStore.get("admin_auth")?.value === "authenticated";
}

export async function GET() {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const testimonials = await db.testimonial.findMany({
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(
      testimonials.map((t) => ({
        ...t,
        createdAt: t.createdAt.toISOString(),
      }))
    );
  } catch (error) {
    console.error("Testimonials fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { name, role, content, rating, country, isFeatured } = body;

    if (!name || !role || !content) {
      return NextResponse.json(
        { error: "Name, role, and content are required" },
        { status: 400 }
      );
    }

    const testimonial = await db.testimonial.create({
      data: {
        name,
        role,
        content,
        rating: parseInt(rating) || 5,
        country: country || null,
        isFeatured: isFeatured === true,
      },
    });

    return NextResponse.json(
      { ...testimonial, createdAt: testimonial.createdAt.toISOString() },
      { status: 201 }
    );
  } catch (error) {
    console.error("Create testimonial error:", error);
    return NextResponse.json({ error: "Failed to create" }, { status: 500 });
  }
}