import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

async function checkAuth() {
  const cookieStore = await cookies();
  return cookieStore.get("admin_auth")?.value === "authenticated";
}

export async function GET(request: NextRequest) {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { searchParams } = request.nextUrl;
    const query = searchParams.get("q")?.toLowerCase() || "";
    const status = searchParams.get("status") || "";
    const sector = searchParams.get("sector") || "";
    const page = parseInt(searchParams.get("page") || "1", 10);
    const limit = parseInt(searchParams.get("limit") || "50", 10);

    const where: Record<string, unknown> = {};

    if (status && status !== "all") {
      where.status = status;
    }

    if (query) {
      where.OR = [
        { name: { contains: query } },
        { city: { contains: query } },
        { licenseNo: { contains: query } },
        { email: { contains: query } },
      ];
    }

    if (sector) {
      where.sectors = { contains: sector };
    }

    const [rawAgencies, total] = await Promise.all([
      db.agency.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: "desc" },
      }),
      db.agency.count({ where }),
    ]);

    const agencies = rawAgencies.map((a) => ({
      ...a,
      sectors: JSON.parse(a.sectors),
      createdAt: a.createdAt.toISOString(),
      updatedAt: a.updatedAt.toISOString(),
    }));

    return NextResponse.json({ agencies, total, page, limit });
  } catch (error) {
    console.error("Admin agencies fetch error:", error);
    return NextResponse.json({ error: "Failed to fetch" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await request.json();
    const {
      name,
      slug,
      licenseNo,
      city,
      address,
      phone,
      email,
      website,
      sectors,
      rating,
      reviewCount,
      isVerified,
      status,
      description,
      foundedYear,
      vacancyCount,
    } = body;

    if (!name || !slug || !licenseNo || !city || !sectors || sectors.length === 0) {
      return NextResponse.json(
        { error: "Name, slug, license number, city, and at least one sector are required" },
        { status: 400 }
      );
    }

    const existing = await db.agency.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ error: "An agency with this slug already exists" }, { status: 409 });
    }

    const agency = await db.agency.create({
      data: {
        name,
        slug,
        licenseNo,
        city,
        address: address || null,
        phone: phone || null,
        email: email || null,
        website: website || null,
        sectors: JSON.stringify(sectors),
        rating: parseFloat(rating) || 0,
        reviewCount: parseInt(reviewCount) || 0,
        isVerified: isVerified === true,
        status: status || "active",
        description: description || null,
        foundedYear: foundedYear ? parseInt(foundedYear) : null,
        vacancyCount: parseInt(vacancyCount) || 0,
      },
    });

    return NextResponse.json({
      ...agency,
      sectors: JSON.parse(agency.sectors),
      createdAt: agency.createdAt.toISOString(),
      updatedAt: agency.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error("Create agency error:", error);
    return NextResponse.json({ error: "Failed to create agency" }, { status: 500 });
  }
}