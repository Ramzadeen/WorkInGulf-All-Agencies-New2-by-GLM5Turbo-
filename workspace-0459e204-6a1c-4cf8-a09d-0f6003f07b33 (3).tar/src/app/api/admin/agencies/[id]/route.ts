import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

async function checkAuth() {
  const cookieStore = await cookies();
  return cookieStore.get("admin_auth")?.value === "authenticated";
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  try {
    const agency = await db.agency.findUnique({ where: { id } });
    if (!agency) {
      return NextResponse.json({ error: "Agency not found" }, { status: 404 });
    }
    return NextResponse.json({
      ...agency,
      sectors: JSON.parse(agency.sectors),
      createdAt: agency.createdAt.toISOString(),
      updatedAt: agency.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error("Fetch agency error:", error);
    return NextResponse.json({ error: "Failed to fetch agency" }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  try {
    const body = await request.json();

    const existing = await db.agency.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Agency not found" }, { status: 404 });
    }

    const {
      name, slug, licenseNo, city, address, phone, email, website,
      sectors, rating, reviewCount, isVerified, status,
      description, foundedYear, vacancyCount,
    } = body;

    // Check slug uniqueness if changed
    if (slug && slug !== existing.slug) {
      const slugExists = await db.agency.findUnique({ where: { slug } });
      if (slugExists) {
        return NextResponse.json({ error: "Slug already in use" }, { status: 409 });
      }
    }

    const agency = await db.agency.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(slug && { slug }),
        ...(licenseNo && { licenseNo }),
        ...(city && { city }),
        ...(address !== undefined && { address: address || null }),
        ...(phone !== undefined && { phone: phone || null }),
        ...(email !== undefined && { email: email || null }),
        ...(website !== undefined && { website: website || null }),
        ...(sectors && { sectors: JSON.stringify(sectors) }),
        ...(rating !== undefined && { rating: parseFloat(rating) || 0 }),
        ...(reviewCount !== undefined && { reviewCount: parseInt(reviewCount) || 0 }),
        ...(isVerified !== undefined && { isVerified: isVerified === true }),
        ...(status && { status }),
        ...(description !== undefined && { description: description || null }),
        ...(foundedYear !== undefined && { foundedYear: foundedYear ? parseInt(foundedYear) : null }),
        ...(vacancyCount !== undefined && { vacancyCount: parseInt(vacancyCount) || 0 }),
      },
    });

    return NextResponse.json({
      ...agency,
      sectors: JSON.parse(agency.sectors),
      createdAt: agency.createdAt.toISOString(),
      updatedAt: agency.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error("Update agency error:", error);
    return NextResponse.json({ error: "Failed to update agency" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  try {
    const existing = await db.agency.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Agency not found" }, { status: 404 });
    }

    await db.agency.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete agency error:", error);
    return NextResponse.json({ error: "Failed to delete agency" }, { status: 500 });
  }
}