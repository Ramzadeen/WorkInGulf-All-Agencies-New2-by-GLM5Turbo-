import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

async function checkAuth() {
  const cookieStore = await cookies();
  return cookieStore.get("admin_auth")?.value === "authenticated";
}

export async function GET() {
  if (!(await checkAuth())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const [totalAgencies, activeAgencies, suspendedAgencies, expiredAgencies, totalTestimonials, totalVacancies, totalPlacements] =
      await Promise.all([
        db.agency.count(),
        db.agency.count({ where: { status: "active" } }),
        db.agency.count({ where: { status: "suspended" } }),
        db.agency.count({ where: { status: "expired" } }),
        db.testimonial.count(),
        db.agency.aggregate({ _sum: { vacancyCount: true } }),
        db.agency.aggregate({ _sum: { reviewCount: true } }),
      ]);

    const topRated = await db.agency.findMany({
      where: { status: "active" },
      orderBy: { rating: "desc" },
      take: 5,
      select: { name: true, slug: true, rating: true, city: true },
    });

    const recentAgencies = await db.agency.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, name: true, city: true, status: true, createdAt: true },
    });

    return NextResponse.json({
      totalAgencies,
      activeAgencies,
      suspendedAgencies,
      expiredAgencies,
      totalTestimonials,
      totalVacancies: totalVacancies._sum.vacancyCount || 0,
      totalPlacements: totalPlacements._sum.reviewCount || 0,
      topRated,
      recentAgencies,
    });
  } catch (error) {
    console.error("Stats error:", error);
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}