"use client";

import { useState, useEffect, createContext, useContext, type ReactNode } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import {
  LayoutDashboard,
  Building2,
  MessageSquareQuote,
  ArrowLeft,
  LogOut,
  ShieldCheck,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

interface AuthContextType {
  isAuth: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ isAuth: false, loading: true });

export function useAdminAuth() {
  return useContext(AuthContext);
}

const sidebarLinks = [
  { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { label: "Agencies", href: "/admin/agencies", icon: Building2 },
  { label: "Testimonials", href: "/admin/testimonials", icon: MessageSquareQuote },
];

export function AdminProvider({ children }: { children: ReactNode }) {
  const [isAuth, setIsAuth] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Check auth by trying to fetch a protected endpoint
    fetch("/api/admin/stats")
      .then((res) => {
        if (res.ok) {
          setIsAuth(true);
        } else {
          setIsAuth(false);
          if (pathname !== "/admin/login") {
            router.replace("/admin/login");
          }
        }
      })
      .catch(() => {
        setIsAuth(false);
        if (pathname !== "/admin/login") {
          router.replace("/admin/login");
        }
      })
      .finally(() => setLoading(false));
  }, [pathname, router]);

  const handleLogout = async () => {
    await fetch("/api/admin/auth", { method: "DELETE" });
    setIsAuth(false);
    router.replace("/admin/login");
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="space-y-3 text-center">
          <Skeleton className="mx-auto h-10 w-10 rounded-xl" />
          <Skeleton className="mx-auto h-4 w-32" />
        </div>
      </div>
    );
  }

  if (pathname === "/admin/login") {
    return <AuthContext.Provider value={{ isAuth: false, loading: false }}>{children}</AuthContext.Provider>;
  }

  if (!isAuth) {
    return null;
  }

  return (
    <AuthContext.Provider value={{ isAuth: true, loading: false }}>
      <div className="flex h-screen overflow-hidden bg-muted/40">
        {/* Sidebar */}
        <aside className="hidden w-64 shrink-0 border-r border-border bg-card lg:flex lg:flex-col">
          <div className="flex h-14 items-center gap-2 border-b border-border px-5">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-emerald-accent">
              <ShieldCheck className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-bold text-foreground">
              Workin<span className="text-emerald-accent">Gulf</span>
            </span>
            <span className="ml-auto rounded bg-emerald-soft px-1.5 py-0.5 text-[10px] font-semibold text-emerald-accent">
              ADMIN
            </span>
          </div>

          <nav className="flex-1 space-y-1 px-3 py-4">
            {sidebarLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-emerald-accent/10 text-emerald-accent"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  <link.icon className="h-4 w-4" />
                  {link.label}
                </Link>
              );
            })}
          </nav>

          <div className="border-t border-border p-3 space-y-1">
            <Link
              href="/"
              className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Site
            </Link>
            <button
              onClick={handleLogout}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </button>
          </div>
        </aside>

        {/* Main Area */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Top Bar */}
          <header className="flex h-14 items-center justify-between border-b border-border bg-card px-6">
            <div>
              <h2 className="text-sm font-semibold text-foreground">
                {sidebarLinks.find((l) => l.href === pathname)?.label || "Admin"}
              </h2>
            </div>

            {/* Mobile menu + User */}
            <div className="flex items-center gap-2">
              {/* Mobile sidebar trigger */}
              <MobileSidebar />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-accent text-xs font-bold text-white">
                      A
                    </div>
                    <span className="hidden sm:inline text-sm">Admin</span>
                    <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem asChild>
                    <Link href="/" className="cursor-pointer">
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back to Site
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={handleLogout}
                    className="text-destructive focus:text-destructive cursor-pointer"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto p-4 sm:p-6">
            {children}
          </main>
        </div>
      </div>
    </AuthContext.Provider>
  );
}

export default function AdminLayout({ children }: { children: ReactNode }) {
  return <AdminProvider>{children}</AdminProvider>;
}

function MobileSidebar() {
  const pathname = usePathname();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="lg:hidden">
          <LayoutDashboard className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-48">
        {sidebarLinks.map((link) => (
          <DropdownMenuItem key={link.href} asChild>
            <Link
              href={link.href}
              className={cn(
                "cursor-pointer",
                pathname === link.href && "bg-emerald-accent/10 text-emerald-accent"
              )}
            >
              <link.icon className="mr-2 h-4 w-4" />
              {link.label}
            </Link>
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/" className="cursor-pointer text-destructive">
            <LogOut className="mr-2 h-4 w-4" />
            Back to Site
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}