"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  Pencil,
  Trash2,
  Star,
  MessageSquareQuote,
  MapPin,
  Loader2,
} from "lucide-react";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatarUrl?: string;
  country?: string;
  isFeatured: boolean;
  createdAt: string;
}

interface TestimonialFormData {
  name: string;
  role: string;
  content: string;
  rating: number;
  country: string;
  isFeatured: boolean;
}

const EMPTY_FORM: TestimonialFormData = {
  name: "",
  role: "",
  content: "",
  rating: 5,
  country: "",
  isFeatured: false,
};

// ─── Star Rating Display ─────────────────────────────────────────────────────

function StarRating({ rating, size = "sm" }: { rating: number; size?: "sm" | "md" }) {
  const iconClass = size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4";
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`${iconClass} ${
            i < rating
              ? "fill-amber-400 text-amber-400"
              : "fill-muted text-muted-foreground/30"
          }`}
        />
      ))}
    </div>
  );
}

// ─── Skeleton Cards ──────────────────────────────────────────────────────────

function SkeletonCards({ count = 6 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <Card key={i} className="p-6">
          <div className="space-y-4">
            {/* Header row */}
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-3.5 w-24" />
              </div>
              <Skeleton className="h-5 w-16 rounded-full" />
            </div>
            {/* Content */}
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            {/* Rating + actions */}
            <div className="flex items-center justify-between">
              <Skeleton className="h-4 w-24" />
              <div className="flex gap-2">
                <Skeleton className="h-8 w-8 rounded-md" />
                <Skeleton className="h-8 w-8 rounded-md" />
              </div>
            </div>
            {/* Date */}
            <Skeleton className="h-3 w-28" />
          </div>
        </Card>
      ))}
    </>
  );
}

// ─── Form Dialog ─────────────────────────────────────────────────────────────

function TestimonialFormDialog({
  initialData,
  onOpenChange,
  onSubmit,
  loading,
}: {
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: TestimonialFormData) => Promise<void>;
  loading: boolean;
  initialData?: TestimonialFormData | null;
}) {
  const [form, setForm] = useState<TestimonialFormData>(
    initialData ? { ...initialData, country: initialData.country ?? "" } : { ...EMPTY_FORM }
  );
  const isEditing = !!initialData;

  const handleChange = (field: keyof TestimonialFormData, value: string | number | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(form);
  };

  const isFormValid = form.name.trim() !== "" && form.role.trim() !== "" && form.content.trim() !== "";

  return (
    <Dialog defaultOpen onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Testimonial" : "Add New Testimonial"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">
              Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="name"
              placeholder="John Doe"
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              required
            />
          </div>

          {/* Role */}
          <div className="space-y-2">
            <Label htmlFor="role">
              Role <span className="text-destructive">*</span>
            </Label>
            <Input
              id="role"
              placeholder="Software Engineer at Google"
              value={form.role}
              onChange={(e) => handleChange("role", e.target.value)}
              required
            />
          </div>

          {/* Content */}
          <div className="space-y-2">
            <Label htmlFor="content">
              Content <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="content"
              placeholder="Write the testimonial content here..."
              value={form.content}
              onChange={(e) => handleChange("content", e.target.value)}
              rows={4}
              className="resize-none"
              required
            />
          </div>

          {/* Rating */}
          <div className="space-y-2">
            <Label htmlFor="rating">Rating</Label>
            <Select
              value={String(form.rating)}
              onValueChange={(val) => handleChange("rating", Number(val))}
            >
              <SelectTrigger id="rating">
                <SelectValue placeholder="Select rating" />
              </SelectTrigger>
              <SelectContent>
                {[5, 4, 3, 2, 1].map((r) => (
                  <SelectItem key={r} value={String(r)}>
                    <span className="flex items-center gap-2">
                      <span className="flex">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3.5 w-3.5 ${
                              i < r
                                ? "fill-amber-400 text-amber-400"
                                : "fill-muted text-muted-foreground/30"
                            }`}
                          />
                        ))}
                      </span>
                      <span>{r} star{r !== 1 ? "s" : ""}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Country */}
          <div className="space-y-2">
            <Label htmlFor="country">Country</Label>
            <Input
              id="country"
              placeholder="United States"
              value={form.country}
              onChange={(e) => handleChange("country", e.target.value)}
            />
          </div>

          {/* isFeatured */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="space-y-0.5">
              <Label htmlFor="isFeatured" className="cursor-pointer">
                Featured
              </Label>
              <p className="text-xs text-muted-foreground">
                Highlight this testimonial prominently
              </p>
            </div>
            <Switch
              id="isFeatured"
              checked={form.isFeatured}
              onCheckedChange={(checked) => handleChange("isFeatured", checked)}
            />
          </div>

          {/* Actions */}
          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-emerald-accent text-white hover:bg-emerald-hover"
              disabled={!isFormValid || loading}
            >
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isEditing ? "Update Testimonial" : "Add Testimonial"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function TestimonialsManagementPage() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTestimonial, setEditingTestimonial] = useState<Testimonial | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [togglingFeaturedId, setTogglingFeaturedId] = useState<string | null>(null);
  const { toast } = useToast();

  // ── Fetch testimonials ──────────────────────────────────────────────────

  const fetchTestimonials = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/testimonials");
      if (!res.ok) throw new Error("Failed to fetch testimonials");
      const data: Testimonial[] = await res.json();
      setTestimonials(data);
    } catch {
      setTestimonials([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTestimonials();
  }, [fetchTestimonials]);

  // ── Submit (Add / Edit) ─────────────────────────────────────────────────

  const handleSubmit = async (data: TestimonialFormData) => {
    setSubmitting(true);
    try {
      if (editingTestimonial) {
        // PUT — edit
        const res = await fetch(`/api/admin/testimonials/${editingTestimonial.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        if (!res.ok) throw new Error("Failed to update testimonial");

        setTestimonials((prev) =>
          prev.map((t) =>
            t.id === editingTestimonial.id ? { ...t, ...data } : t
          )
        );

        toast({
          title: "Testimonial updated",
          description: `"${data.name}" has been updated successfully.`,
        });
      } else {
        // POST — add
        const res = await fetch("/api/admin/testimonials", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        if (!res.ok) throw new Error("Failed to create testimonial");

        const newTestimonial: Testimonial = await res.json();
        setTestimonials((prev) => [newTestimonial, ...prev]);

        toast({
          title: "Testimonial added",
          description: `"${data.name}" has been added successfully.`,
        });
      }

      setDialogOpen(false);
      setEditingTestimonial(null);
    } catch {
      toast({
        title: "Error",
        description: editingTestimonial
          ? "Failed to update the testimonial. Please try again."
          : "Failed to create the testimonial. Please try again.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // ── Toggle Featured ─────────────────────────────────────────────────────

  const handleToggleFeatured = async (testimonial: Testimonial) => {
    setTogglingFeaturedId(testimonial.id);
    try {
      const newValue = !testimonial.isFeatured;
      const res = await fetch(`/api/admin/testimonials/${testimonial.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFeatured: newValue }),
      });
      if (!res.ok) throw new Error("Failed to toggle featured status");

      // Optimistic update already set, just confirm
      setTestimonials((prev) =>
        prev.map((t) =>
          t.id === testimonial.id ? { ...t, isFeatured: newValue } : t
        )
      );

      toast({
        title: newValue ? "Marked as featured" : "Removed from featured",
        description: `"${testimonial.name}" has been ${newValue ? "marked as featured" : "removed from featured"}.`,
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to update featured status. Please try again.",
      });
    } finally {
      setTogglingFeaturedId(null);
    }
  };

  // ── Delete ──────────────────────────────────────────────────────────────

  const handleDelete = async () => {
    if (!deletingId) return;
    try {
      const res = await fetch(`/api/admin/testimonials/${deletingId}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Failed to delete testimonial");

      const deletedTestimonial = testimonials.find((t) => t.id === deletingId);
      setTestimonials((prev) => prev.filter((t) => t.id !== deletingId));

      toast({
        title: "Testimonial deleted",
        description: `"${deletedTestimonial?.name ?? "The testimonial"}" has been permanently removed.`,
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to delete the testimonial. Please try again.",
      });
    } finally {
      setDeletingId(null);
      setDeleteDialogOpen(false);
    }
  };

  // ── Open edit dialog ────────────────────────────────────────────────────

  const openEditDialog = (testimonial: Testimonial) => {
    setEditingTestimonial(testimonial);
    setDialogOpen(true);
  };

  // ── Open add dialog ─────────────────────────────────────────────────────

  const openAddDialog = () => {
    setEditingTestimonial(null);
    setDialogOpen(true);
  };

  // ── Format date ─────────────────────────────────────────────────────────

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // ── Render ──────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ── Page Header ─────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Testimonials Management
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {loading
              ? "Loading testimonials..."
              : `${testimonials.length} ${testimonials.length === 1 ? "testimonial" : "testimonials"}`}
          </p>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-emerald-accent text-white hover:bg-emerald-hover"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Testimonial
        </Button>
      </div>

      {/* ── Testimonials Grid ────────────────────────────────────────── */}
      {loading ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          <SkeletonCards count={6} />
        </div>
      ) : testimonials.length === 0 ? (
        <Card className="flex flex-col items-center justify-center gap-3 py-20">
          <MessageSquareQuote className="h-12 w-12 text-muted-foreground/50" />
          <p className="text-lg font-medium text-muted-foreground">
            No testimonials yet
          </p>
          <p className="text-sm text-muted-foreground">
            Click &quot;Add Testimonial&quot; to create your first testimonial.
          </p>
          <Button
            onClick={openAddDialog}
            className="mt-2 bg-emerald-accent text-white hover:bg-emerald-hover"
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Testimonial
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2, delay: index * 0.03 }}
              >
                <Card className="flex h-full flex-col transition-shadow hover:shadow-md">
                  <CardHeader className="pb-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <h3 className="truncate text-base font-semibold leading-tight">
                          {testimonial.name}
                        </h3>
                        <p className="truncate text-sm text-muted-foreground">
                          {testimonial.role}
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-1.5">
                        {testimonial.isFeatured && (
                          <Badge
                            className="bg-emerald-soft text-emerald-accent hover:bg-emerald-soft/80 cursor-pointer select-none"
                            onClick={() => handleToggleFeatured(testimonial)}
                            title="Click to remove from featured"
                          >
                            Featured
                          </Badge>
                        )}
                        {!testimonial.isFeatured && (
                          <Badge
                            variant="outline"
                            className="cursor-pointer select-none text-muted-foreground hover:text-foreground"
                            onClick={() => handleToggleFeatured(testimonial)}
                            title="Click to mark as featured"
                          >
                            Not Featured
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="flex flex-1 flex-col justify-between gap-3 pt-3">
                    {/* Content */}
                    <p className="line-clamp-3 text-sm leading-relaxed text-muted-foreground">
                      &ldquo;{testimonial.content}&rdquo;
                    </p>

                    {/* Rating */}
                    <div className="flex items-center gap-2">
                      <StarRating rating={testimonial.rating} />
                      <span className="text-xs text-muted-foreground">
                        {testimonial.rating}.0
                      </span>
                    </div>

                    {/* Country + Date + Actions */}
                    <div className="flex items-center justify-between border-t pt-3">
                      <div className="flex flex-col gap-1">
                        {testimonial.country && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <MapPin className="h-3 w-3" />
                            <span>{testimonial.country}</span>
                          </div>
                        )}
                        <span className="text-xs text-muted-foreground/70">
                          {formatDate(testimonial.createdAt)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {togglingFeaturedId === testimonial.id ? (
                          <Button variant="ghost" size="icon" disabled>
                            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                            <span className="sr-only">Toggling featured</span>
                          </Button>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(testimonial)}
                          >
                            <Pencil className="h-4 w-4 text-muted-foreground hover:text-emerald-accent" />
                            <span className="sr-only">Edit {testimonial.name}</span>
                          </Button>
                        )}

                        <AlertDialog
                          open={deleteDialogOpen && deletingId === testimonial.id}
                          onOpenChange={(open) => {
                            setDeleteDialogOpen(open);
                            if (!open) setDeletingId(null);
                          }}
                        >
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setDeletingId(testimonial.id);
                                setDeleteDialogOpen(true);
                              }}
                            >
                              <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                              <span className="sr-only">
                                Delete {testimonial.name}
                              </span>
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                Delete &quot;{testimonial.name}&quot;&apos;s testimonial?
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. This will
                                permanently delete the testimonial from the
                                system.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={handleDelete}
                                className="bg-destructive text-white hover:bg-destructive/90"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* ── Form Dialog ──────────────────────────────────────────────── */}
      {dialogOpen && (
        <TestimonialFormDialog
          key={editingTestimonial?.id ?? "new"}
          initialData={
            editingTestimonial
              ? {
                  name: editingTestimonial.name,
                  role: editingTestimonial.role,
                  content: editingTestimonial.content,
                  rating: editingTestimonial.rating,
                  country: editingTestimonial.country ?? "",
                  isFeatured: editingTestimonial.isFeatured,
                }
              : null
          }
          onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) setEditingTestimonial(null);
          }}
          onSubmit={handleSubmit}
          loading={submitting}
        />
      )}
    </div>
  );
}