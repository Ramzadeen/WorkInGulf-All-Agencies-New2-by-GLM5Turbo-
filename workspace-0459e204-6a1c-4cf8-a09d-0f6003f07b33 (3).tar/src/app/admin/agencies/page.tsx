"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Plus,
  Pencil,
  Trash2,
  Star,
  Building2,
  AlertCircle,
} from "lucide-react";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Agency {
  id: string;
  name: string;
  slug: string;
  licenseNo: string;
  city: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  sectors: string[];
  rating: number;
  reviewCount: number;
  isVerified: boolean;
  status: "active" | "suspended" | "expired";
  description: string;
  foundedYear: number;
  vacancyCount: number;
  createdAt: string;
  updatedAt: string;
}

interface AgenciesResponse {
  agencies: Agency[];
  total: number;
  page: number;
  limit: number;
}

// ─── Status badge helper ────────────────────────────────────────────────────

function StatusBadge({ status }: { status: Agency["status"] }) {
  switch (status) {
    case "active":
      return (
        <Badge
          variant="secondary"
          className="bg-emerald-soft text-emerald-accent capitalize"
        >
          Active
        </Badge>
      );
    case "suspended":
      return (
        <Badge
          variant="secondary"
          className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 capitalize"
        >
          Suspended
        </Badge>
      );
    case "expired":
      return (
        <Badge
          variant="secondary"
          className="bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 capitalize"
        >
          Expired
        </Badge>
      );
    default:
      return null;
  }
}

// ─── Skeleton rows ──────────────────────────────────────────────────────────

function TableSkeleton({ rows = 8 }: { rows?: number }) {
  return (
    <>
      {Array.from({ length: rows }).map((_, i) => (
        <TableRow key={i}>
          <TableCell>
            <Skeleton className="h-4 w-36 mb-1" />
            <Skeleton className="h-3 w-24" />
          </TableCell>
          <TableCell className="hidden md:table-cell">
            <Skeleton className="h-4 w-20" />
          </TableCell>
          <TableCell className="hidden lg:table-cell">
            <div className="flex gap-1">
              <Skeleton className="h-5 w-14 rounded-full" />
              <Skeleton className="h-5 w-16 rounded-full" />
            </div>
          </TableCell>
          <TableCell>
            <div className="flex items-center gap-1">
              <Skeleton className="h-4 w-4" />
              <Skeleton className="h-4 w-8" />
            </div>
          </TableCell>
          <TableCell>
            <Skeleton className="h-5 w-16 rounded-full" />
          </TableCell>
          <TableCell className="hidden md:table-cell">
            <Skeleton className="h-4 w-8" />
          </TableCell>
          <TableCell>
            <div className="flex gap-2">
              <Skeleton className="h-8 w-8 rounded-md" />
              <Skeleton className="h-8 w-8 rounded-md" />
            </div>
          </TableCell>
        </TableRow>
      ))}
    </>
  );
}

// ─── Main component ─────────────────────────────────────────────────────────

export default function AgenciesManagementPage() {
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const { toast } = useToast();

  // ── Fetch agencies ──────────────────────────────────────────────────────

  const fetchAgencies = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: "1",
        limit: "50",
      });
      if (searchQuery.trim()) {
        params.set("q", searchQuery.trim());
      }
      if (statusFilter && statusFilter !== "all") {
        params.set("status", statusFilter);
      }

      const res = await fetch(`/api/admin/agencies?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch agencies");
      const data: AgenciesResponse = await res.json();
      setAgencies(data.agencies);
      setTotal(data.total);
    } catch {
      setAgencies([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [searchQuery, statusFilter]);

  useEffect(() => {
    fetchAgencies();
  }, [fetchAgencies]);

  // ── Delete agency ───────────────────────────────────────────────────────

  const handleDelete = async () => {
    if (!deletingId) return;
    try {
      const res = await fetch(`/api/admin/agencies/${deletingId}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Failed to delete agency");

      const deletedAgency = agencies.find((a) => a.id === deletingId);
      setAgencies((prev) => prev.filter((a) => a.id !== deletingId));
      setTotal((prev) => Math.max(0, prev - 1));
      toast({
        title: "Agency deleted",
        description: `"${deletedAgency?.name ?? "The agency"}" has been permanently removed.`,
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to delete the agency. Please try again.",
      });
    } finally {
      setDeletingId(null);
      setDeleteDialogOpen(false);
    }
  };

  // ── Debounced search ────────────────────────────────────────────────────

  const [debouncedQuery, setDebouncedQuery] = useState("");
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Update searchQuery ref used in fetchAgencies
  useEffect(() => {
    setSearchQuery(debouncedQuery);
  }, [debouncedQuery]);

  // ── Render ──────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ── Page Header ─────────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Agencies Management
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {loading
              ? "Loading agencies..."
              : `${total} ${total === 1 ? "agency" : "agencies"} found`}
          </p>
        </div>
        <Button asChild className="bg-emerald-accent text-white hover:bg-emerald-hover">
          <Link href="/admin/agencies/new">
            <Plus className="mr-2 h-4 w-4" />
            Add New Agency
          </Link>
        </Button>
      </div>

      {/* ── Search & Filter Bar ─────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by name, city, license, email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="suspended">Suspended</SelectItem>
            <SelectItem value="expired">Expired</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* ── Agencies Table ──────────────────────────────────────────── */}
      <div className="rounded-lg border bg-card">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[200px]">Name / License</TableHead>
                <TableHead className="hidden md:table-cell">City</TableHead>
                <TableHead className="hidden lg:table-cell">Sectors</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden md:table-cell">
                  Vacancies
                </TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {loading ? (
                <TableSkeleton rows={8} />
              ) : agencies.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7}>
                    <div className="flex flex-col items-center justify-center gap-2 py-16 text-muted-foreground">
                      <AlertCircle className="h-10 w-10" />
                      <p className="text-lg font-medium">No agencies found</p>
                      <p className="text-sm">
                        Try adjusting your search or filter criteria.
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                <AnimatePresence mode="popLayout">
                  {agencies.map((agency, index) => (
                    <motion.tr
                      key={agency.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2, delay: index * 0.03 }}
                      className="group border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted"
                    >
                      {/* Name + License */}
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-soft">
                            <Building2 className="h-4 w-4 text-emerald-accent" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="truncate font-medium">
                                {agency.name}
                              </span>
                              {agency.isVerified && (
                                <svg
                                  className="h-3.5 w-3.5 shrink-0 text-emerald-accent"
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path
                                    fillRule="evenodd"
                                    d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                    clipRule="evenodd"
                                  />
                                </svg>
                              )}
                            </div>
                            <p className="truncate text-xs text-muted-foreground">
                              {agency.licenseNo}
                            </p>
                          </div>
                        </div>
                      </TableCell>

                      {/* City */}
                      <TableCell className="hidden md:table-cell">
                        <span className="text-sm">{agency.city}</span>
                      </TableCell>

                      {/* Sectors */}
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {agency.sectors.slice(0, 3).map((sector) => (
                            <Badge
                              key={sector}
                              variant="outline"
                              className="text-xs font-normal"
                            >
                              {sector}
                            </Badge>
                          ))}
                          {agency.sectors.length > 3 && (
                            <Badge
                              variant="outline"
                              className="text-xs font-normal text-muted-foreground"
                            >
                              +{agency.sectors.length - 3}
                            </Badge>
                          )}
                        </div>
                      </TableCell>

                      {/* Rating */}
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                          <span className="text-sm font-medium">
                            {agency.rating.toFixed(1)}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            ({agency.reviewCount})
                          </span>
                        </div>
                      </TableCell>

                      {/* Status */}
                      <TableCell>
                        <StatusBadge status={agency.status} />
                      </TableCell>

                      {/* Vacancies */}
                      <TableCell className="hidden md:table-cell">
                        <span className="text-sm font-medium">
                          {agency.vacancyCount}
                        </span>
                      </TableCell>

                      {/* Actions */}
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" asChild>
                            <Link href={`/admin/agencies/${agency.id}`}>
                              <Pencil className="h-4 w-4 text-muted-foreground hover:text-emerald-accent" />
                              <span className="sr-only">Edit {agency.name}</span>
                            </Link>
                          </Button>

                          <AlertDialog
                            open={
                              deleteDialogOpen && deletingId === agency.id
                            }
                            onOpenChange={(open) => {
                              setDeleteDialogOpen(open);
                              if (!open) setDeletingId(null);
                            }}
                          >
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setDeletingId(agency.id);
                                  setDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                                <span className="sr-only">
                                  Delete {agency.name}
                                </span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>
                                  Delete &quot;{agency.name}&quot;?
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  This action cannot be undone. This will
                                  permanently delete the agency and all its
                                  associated data from the system.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={handleDelete}
                                  className="bg-destructive text-white hover:bg-destructive/90"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}