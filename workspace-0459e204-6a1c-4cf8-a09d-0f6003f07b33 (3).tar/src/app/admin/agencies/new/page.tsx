import AgencyForm from "@/components/admin/AgencyForm";

export default function NewAgencyPage() {
  return <AgencyForm />;
}