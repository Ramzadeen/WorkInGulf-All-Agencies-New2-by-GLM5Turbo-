"use client";

import { useParams } from "next/navigation";
import AgencyForm from "@/components/admin/AgencyForm";

export default function EditAgencyPage() {
  const params = useParams<{ id: string }>();
  return <AgencyForm agencyId={params.id} />;
}