"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Save, ArrowLeft, Building2, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

import { ALL_SECTORS, type Sector } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface AgencyFormProps {
  agencyId?: string;
}

interface FormData {
  name: string;
  slug: string;
  licenseNo: string;
  city: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  description: string;
  foundedYear: string;
  rating: string;
  reviewCount: string;
  vacancyCount: string;
  status: string;
  isVerified: boolean;
  sectors: string[];
}

const DEFAULT_FORM_DATA: FormData = {
  name: "",
  slug: "",
  licenseNo: "",
  city: "",
  address: "",
  phone: "",
  email: "",
  website: "",
  description: "",
  foundedYear: "",
  rating: "",
  reviewCount: "",
  vacancyCount: "",
  status: "active",
  isVerified: false,
  sectors: [],
};

function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

export default function AgencyForm({ agencyId }: AgencyFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const isEditMode = !!agencyId;

  const [formData, setFormData] = useState<FormData>(DEFAULT_FORM_DATA);
  const [loading, setLoading] = useState(isEditMode);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [slugManuallyEdited, setSlugManuallyEdited] = useState(false);

  // Fetch agency data in edit mode
  useEffect(() => {
    if (!agencyId) return;

    async function fetchAgency() {
      try {
        setLoading(true);
        const res = await fetch(`/api/admin/agencies/${agencyId}`);
        if (!res.ok) {
          throw new Error("Failed to fetch agency data");
        }
        const agency = await res.json();
        setFormData({
          name: agency.name ?? "",
          slug: agency.slug ?? "",
          licenseNo: agency.licenseNo ?? "",
          city: agency.city ?? "",
          address: agency.address ?? "",
          phone: agency.phone ?? "",
          email: agency.email ?? "",
          website: agency.website ?? "",
          description: agency.description ?? "",
          foundedYear: agency.foundedYear ? String(agency.foundedYear) : "",
          rating: agency.rating != null ? String(agency.rating) : "",
          reviewCount:
            agency.reviewCount != null ? String(agency.reviewCount) : "",
          vacancyCount:
            agency.vacancyCount != null ? String(agency.vacancyCount) : "",
          status: agency.status ?? "active",
          isVerified: agency.isVerified ?? false,
          sectors: Array.isArray(agency.sectors) ? agency.sectors : [],
        });
        // In edit mode, mark slug as manually edited so we don't auto-generate
        setSlugManuallyEdited(true);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to load agency data"
        );
      } finally {
        setLoading(false);
      }
    }

    fetchAgency();
  }, [agencyId]);

  const updateField = useCallback(
    <K extends keyof FormData>(key: K, value: FormData[K]) => {
      setFormData((prev) => {
        const next = { ...prev, [key]: value };
        // Auto-generate slug from name if user hasn't manually edited it
        if (key === "name" && !slugManuallyEdited) {
          next.slug = generateSlug(value as string);
        }
        return next;
      });
    },
    [slugManuallyEdited]
  );

  const toggleSector = useCallback((sector: Sector) => {
    setFormData((prev) => {
      const exists = prev.sectors.includes(sector);
      return {
        ...prev,
        sectors: exists
          ? prev.sectors.filter((s) => s !== sector)
          : [...prev.sectors, sector],
      };
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const payload = {
        name: formData.name,
        slug: formData.slug,
        licenseNo: formData.licenseNo,
        city: formData.city,
        address: formData.address || null,
        phone: formData.phone || null,
        email: formData.email || null,
        website: formData.website || null,
        description: formData.description || null,
        foundedYear: formData.foundedYear
          ? parseInt(formData.foundedYear, 10)
          : null,
        rating: formData.rating ? parseFloat(formData.rating) : null,
        reviewCount: formData.reviewCount
          ? parseInt(formData.reviewCount, 10)
          : null,
        vacancyCount: formData.vacancyCount
          ? parseInt(formData.vacancyCount, 10)
          : null,
        status: formData.status,
        isVerified: formData.isVerified,
        sectors: formData.sectors,
      };

      const url = isEditMode
        ? `/api/admin/agencies/${agencyId}`
        : "/api/admin/agencies";
      const method = isEditMode ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Failed to ${isEditMode ? "update" : "create"} agency`);
      }

      toast({
        title: isEditMode ? "Agency updated" : "Agency created",
        description: `"${formData.name}" has been ${isEditMode ? "updated" : "created"} successfully.`,
      });

      router.push("/admin/agencies");
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong"
      );
    } finally {
      setSubmitting(false);
    }
  };

  // Loading skeleton for edit mode
  if (loading) {
    return (
      <div className="space-y-6 p-4 md:p-6 lg:p-8">
        <div className="flex items-center gap-3">
          <Skeleton className="h-8 w-8 rounded" />
          <Skeleton className="h-8 w-64" />
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-10 w-full rounded-md" />
            </div>
          ))}
        </div>
        <div className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-24 w-full rounded-md" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Link href="/admin/agencies">
            <Button variant="ghost" size="icon" className="shrink-0">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Back to agencies</span>
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-muted-foreground" />
            <h1 className="text-xl font-bold tracking-tight sm:text-2xl">
              {isEditMode ? "Edit Agency" : "New Agency"}
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/admin/agencies">
            <Button variant="outline">Cancel</Button>
          </Link>
          <Button
            type="submit"
            form="agency-form"
            disabled={submitting}
            className="bg-emerald-accent text-white hover:bg-emerald-hover"
          >
            {submitting ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            {isEditMode ? "Update Agency" : "Create Agency"}
          </Button>
        </div>
      </div>

      {/* Error message */}
      {error && (
        <div className="rounded-md border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      )}

      <form id="agency-form" onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle asChild>
              <h3 className="text-base font-semibold text-foreground">
                Basic Info
              </h3>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">
                  Agency Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="name"
                  placeholder="Enter agency name"
                  value={formData.name}
                  onChange={(e) => updateField("name", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slug">
                  Slug <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="slug"
                  placeholder="auto-generated-from-name"
                  value={formData.slug}
                  onChange={(e) => {
                    setSlugManuallyEdited(true);
                    updateField("slug", e.target.value);
                  }}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="licenseNo">
                  License Number <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="licenseNo"
                  placeholder="e.g. REC-2024-001"
                  value={formData.licenseNo}
                  onChange={(e) => updateField("licenseNo", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">
                  City <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="city"
                  placeholder="Enter city"
                  value={formData.city}
                  onChange={(e) => updateField("city", e.target.value)}
                  required
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle asChild>
              <h3 className="text-base font-semibold text-foreground">
                Contact
              </h3>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="space-y-2 lg:col-span-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  placeholder="Street address"
                  value={formData.address}
                  onChange={(e) => updateField("address", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  placeholder="+1 234 567 890"
                  value={formData.phone}
                  onChange={(e) => updateField("phone", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="contact@agency.com"
                  value={formData.email}
                  onChange={(e) => updateField("email", e.target.value)}
                />
              </div>
              <div className="space-y-2 lg:col-span-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  type="url"
                  placeholder="https://www.agency.com"
                  value={formData.website}
                  onChange={(e) => updateField("website", e.target.value)}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Details */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle asChild>
              <h3 className="text-base font-semibold text-foreground">
                Details
              </h3>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  rows={3}
                  placeholder="Brief description of the agency..."
                  value={formData.description}
                  onChange={(e) => updateField("description", e.target.value)}
                />
              </div>
              <div className="grid gap-4 lg:grid-cols-2 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="foundedYear">Founded Year</Label>
                  <Input
                    id="foundedYear"
                    type="number"
                    placeholder="e.g. 2020"
                    value={formData.foundedYear}
                    onChange={(e) =>
                      updateField("foundedYear", e.target.value)
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rating">Rating</Label>
                  <Input
                    id="rating"
                    type="number"
                    min="0"
                    max="5"
                    step="0.1"
                    placeholder="0 - 5"
                    value={formData.rating}
                    onChange={(e) => updateField("rating", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reviewCount">Review Count</Label>
                  <Input
                    id="reviewCount"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={formData.reviewCount}
                    onChange={(e) =>
                      updateField("reviewCount", e.target.value)
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vacancyCount">Vacancy Count</Label>
                  <Input
                    id="vacancyCount"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={formData.vacancyCount}
                    onChange={(e) =>
                      updateField("vacancyCount", e.target.value)
                    }
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle asChild>
              <h3 className="text-base font-semibold text-foreground">
                Settings
              </h3>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => updateField("status", value)}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-3 rounded-lg border p-4">
                <Switch
                  id="isVerified"
                  checked={formData.isVerified}
                  onCheckedChange={(checked) =>
                    updateField("isVerified", checked)
                  }
                />
                <Label htmlFor="isVerified" className="cursor-pointer select-none">
                  Verified Agency
                </Label>
              </div>
            </div>

            {/* Sectors */}
            <div className="space-y-3">
              <Label>Sectors</Label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {ALL_SECTORS.map((sector) => {
                  const isSelected = formData.sectors.includes(sector);
                  return (
                    <button
                      key={sector}
                      type="button"
                      onClick={() => toggleSector(sector)}
                      className={cn(
                        "inline-flex items-center justify-center rounded-md border px-3 py-2 text-sm font-medium transition-colors cursor-pointer",
                        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                        isSelected
                          ? "bg-emerald-accent text-white border-emerald-accent hover:bg-emerald-hover"
                          : "bg-muted text-muted-foreground border-transparent hover:bg-muted/80"
                      )}
                    >
                      {sector}
                    </button>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}